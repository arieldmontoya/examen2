### EXAMEN 2 CEUTEC

Crear proyecto de JAVA maven
Crear una base de datos en MongoDB con nombre Produccion, luego crear una coleccion con nombre Maquinaria.
Crear un documento con la estructura de clases adjunto
Crear una clase para la conexion de JAVA con MongoDB, utilizar las dependencias vistas en clase y los metodos necesarios para la conexion.
Crear un formulario en JAVA con el nombre maquinaria donde pueda realizar un CRUD a la base de datos de MongoDB creado anteriormente.
"# examen2" 
